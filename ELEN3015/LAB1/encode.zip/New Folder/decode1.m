%%%This is program which writes a string onto an image of any format. 
%%%The output is a tif image 'great.tif' with no visible changes in it.
%%%use the decode1.m to open great.tif and see the hidden text.This is my
%%%first matlab project so please contact me to furthur improve the program
%%%and to help me with my future projects.my email id is sharaths24@yahoo.com


[file, pathname] = uigetfile('great.bmp', 'Image');%open the image
buffer=pwd;
cd (pathname);
[I,map]=imread(file);

cd (buffer);
I=double(I);%convert the image array to double format


w=I(:,1,1);%access a column
lenw=length(w);%find the number of columns

t=I(lenw,:,3);%access the last column


i=I(1,1,1);%access this element to find the length of the hidden string
f=t(:,1:i);%print the hidden string
char(f)
