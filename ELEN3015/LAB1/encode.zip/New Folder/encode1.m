%%%This is program which writes a string onto an image of any format. 
%%%The output is a tif image 'great.tif' with no visible changes in it.
%%%use the decode1.m to open great.tif and see the hidden text.This is my
%%%first matlab project so please contact me to furthur improve the program
%%%and to help me with my future projects.my email id is sharaths24@yahoo.com


[file, pathname] = uigetfile('*.*', 'Image');%open the image
buffer=pwd;
cd (pathname);
[I,map]=imread(file);

cd (buffer);
xlen=I(1,:,3);%access the row


len=length(xlen);%find row length
ch=input('type the text you want to hide in the image-->  ','s');
lench=length(ch);%length of the input string
I(1,1,1)=lench;%store the length of the string in the picture
s=uint8(ch);%convert the text to a uint8 array
dif=len-lench;%find difference between the row length and the uint8 text length
t=1:1:dif;%create a row of having 'dif' number of columns
x=[s t];%create the uint8 text row concatenated with t  
w=I(:,1,1);%access any column
lenw=length(w);%find the number of columns



I(lenw,:,3)=x;%replace the last row with x i.e the text row
imwrite(I,'great.bmp','bmp');%.tif format can also be used but not .jpeg
disp('text sucessfully hidden in great.bmp in the matlab work directory, use decode1 to view the hidden text!! '); 
